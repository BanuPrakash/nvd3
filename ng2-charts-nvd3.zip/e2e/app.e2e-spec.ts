import { Ng2ChartsNvd3Page } from './app.po';

describe('ng2-charts-nvd3 App', () => {
  let page: Ng2ChartsNvd3Page;

  beforeEach(() => {
    page = new Ng2ChartsNvd3Page();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
