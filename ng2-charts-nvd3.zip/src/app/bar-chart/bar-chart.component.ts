import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';

declare let d3: any;
import {nvD3} from 'ng2-nvd3'

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.css']
})
export class BarChartComponent implements OnInit {

  options;
  data;

  @ViewChild(nvD3)
  nvD3: nvD3;

  ngOnInit(){
    this.options = {
      chart: {
        type: 'discreteBarChart',
        height: 450,
        margin : {
          top: 20,
          right: 20,
          bottom: 50,
          left: 55
        },
        x: function(d){return d.label;},
        y: function(d){return d.value;},
        showValues: true,
        valueFormat: function(d){
          return d3.format(',.2f')(d);
        },
        duration: 500,
        xAxis: {
          axisLabel: 'Day'
        },
        yAxis: {
          axisLabel: 'Sales',
          axisLabelDistance: -10
        }
      }
    }
    this.data = [
      {
        key: "Cumulative Return",
        values: [
          {
            "label" : "Sunday" ,
            "value" : 42129
          } ,
          {
            "label" : "Monday" ,
            "value" : 5252
          } ,
          {
            "label" : "Tuesday" ,
            "value" : 32245
          } ,
          {
            "label" : "Thursday" ,
            "value" : 19656
          } ,
          {
            "label" : "Friday" ,
            "value" : 19462
          } ,
          {
            "label" : "Saturday" ,
            "value" : 40824
          } 
        ]
      }
    ];
  }

   ngAfterViewInit() {
     this.nvD3.chart.update()
  } 

}
