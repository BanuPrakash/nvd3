import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';

declare let d3: any;
import {nvD3} from 'ng2-nvd3'

@Component({
  selector: 'app-donut-chart',
  templateUrl: './donut-chart.component.html',
  styleUrls: ['./donut-chart.component.css']
})
export class DonutChartComponent implements OnInit {

  options;
  data;

  @ViewChild(nvD3)
  nvD3: nvD3;

  ngOnInit(){
    this.options = {
      chart: {
      type: 'pieChart',
      donut: true,
      height: 500,
      x: function(d){return d.key;},
      y: function(d){return d.y;},
      /*showValues: false,*/
      showLabels: true,
      duration: 500,
     /* labelThreshold: 0.01,
      labelSunbeamLayout: true,*/
      legend: {
        margin: {
          top: 5,
          right: 35,
          bottom: 5,
          left: 0
        }
      }
    }
    }
    this.data = [
    {
      key: "Pepsi Soda",
      y: 35
    },
    {
      key: "Aquafina Bottled Water",
      y: 40
    },
    {
      key: "7 Up",
      y: 15
    },
    {
      key: "Lays Classic",
      y: 8
    },
    {
      key: "Cheetos",
      y: 2
    }
  ];
  }

   ngAfterViewInit() {
     this.nvD3.chart.update()
  } 

}
