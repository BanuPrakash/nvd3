import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';

declare let d3: any;
import {nvD3} from 'ng2-nvd3'

@Component({
  selector: 'app-horizontal-bar-chart',
  templateUrl: './horizontal-bar-chart.component.html',
  styleUrls: ['./horizontal-bar-chart.component.css']
})
export class HorizontalBarChartComponent implements OnInit {
 
  options;
  data;

  @ViewChild(nvD3)
  nvD3: nvD3;

  ngOnInit(){
    this.options = {
      chart: {
    		"type": "multiBarHorizontalChart",
    		"height": 250,
    		"showControls": true,
    		"showValues": true,
    		"duration": 500,
    		"xAxis": {
      			"showMaxMin": true
    		},
    		"yAxis": {
      			"axisLabel": "Sales"
    		},
 	        x: function(d){return d.label;},
    	    y: function(d){return d.value;}
          }	
      },
    this.data = [
      {
        key: "Pepsi Units Sales by Territory",
        color: "#1f77b4",
        values: [
          {
            "label" : "USA" ,
            "value" : 42129
          } ,
          {
            "label" : "India" ,
            "value" : 36000
          } ,
          {
            "label" : "England" ,
            "value" : 32245
          } ,
          {
            "label" : "Malasia" ,
            "value" : 19656
          } ,
          {
            "label" : "Brazil" ,
            "value" : 19462
          } 
        ]
      },
      {
        key: "Lays Units Sales by Territory",
        color: "#d62728",
        values: [
          {
            "label" : "USA" ,
            "value" : 1340
          } ,
          {
            "label" : "India" ,
            "value" : 2460
          } ,
          {
            "label" : "England" ,
            "value" : 1245
          } ,
          {
            "label" : "Malasia" ,
            "value" : 356
          } ,
          {
            "label" : "Brazil" ,
            "value" : 512
          } 
        ]
      }
    ];
  }

   ngAfterViewInit() {
     this.nvD3.chart.update()
  } 

}
